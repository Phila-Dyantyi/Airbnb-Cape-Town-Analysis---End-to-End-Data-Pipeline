# Cape Town Airbnb — Data Engineering Case Study

A end-to-end data engineering project analysing Cape Town Airbnb listings and their correlation with weather conditions. Built as a Deloitte Data Engineer case study submission.

**Author:** Phila Dyantyi

---

## Project Overview

This project collects, transforms, and analyses Airbnb listing data for Cape Town alongside historical meteorological data, with the goal of identifying correlations between weather conditions and guest ratings, and surfacing location/property-type trends.

### Key Finding
> There is no meaningful correlation between weather and ratings. Cleanliness, perceived value, and price are the stronger predictors of rating outcomes.

---

## Architecture

```
Raw Sources (CSV / API)
        │
        ▼
[Python Ingest]  ─────────────────────────────────────
  InsideAirbnb listings (Jun & Sep 2025)               │
  Open-Meteo historical weather API                     │
        │                                               │
        ▼                                               │
  Ingest/                                               │
    cape_town_airbnb_raw_combined.csv                   │
    cape_town_weather_sep2025.csv                       │
        │                                               │
        ▼                                               ▼
[SQL Server — CapeTownAirbnb Database]          [Data Model]
  STG schema  → raw landing (all NVARCHAR)     CapeTownAirbnb_Model.drawio
  STG schema  → clean tables (typed)
  DWH schema  → dimensional model
        │
        ▼
[Analysis & Dashboard]
  Dashboard_Analysis.pptx
```

---

## Repository Structure

```
├── ingest/
│   └── ingest_file.py             # Python ingestion script
│
├── sql/
│   └── CapeTownAirbnb_file.sql    # DDL + DML: staging, cleaning, DWH
│
├── model/
│   └── CapeTownAirbnb_Model.drawio  # Data model diagram
│
├── dashboard/
│   └── Dashboard_Analysis.pptx   # 2-slide analysis deck
│
└── docs/
    └── DE_Case_study.docx         # Case study brief + engineering notes
```

---

## Data Sources

| Source | Description |
|---|---|
| [InsideAirbnb](https://insideairbnb.com/get-the-data/) | Cape Town listings — June 2025 & September 2025 snapshots |
| [Open-Meteo Archive API](https://open-meteo.com/) | Daily historical weather for Cape Town (no API key required) |

**Note on data availability:** The case study originally specified the December 2023 InsideAirbnb dataset, which was unavailable at submission time (data request submitted, 2–4 week lead time). June and September 2025 snapshots were used instead. Similarly, OpenWeather's historical API required a paid subscription, so Open-Meteo was selected as a free, keyless alternative.

---

## How to Run

### 1. Ingest data

```bash
pip install requests pandas
python ingest/ingest_file.py
```

This creates an `Ingest/` folder containing:
- `cape_town_airbnb_raw_combined.csv`
- `cape_town_weather_sep2025.csv`

### 2. Load and transform in SQL Server

Open `sql/CapeTownAirbnb_file.sql` in SSMS and run it in order.

> **Before running:** update the `BULK INSERT` file paths in Step 5 to match your local `Ingest/` directory.

The script executes these steps:
1. Creates the `CapeTownAirbnb` database
2. Creates `STG` and `DWH` schemas
3. Creates an ETL log table
4. Creates raw staging tables (all `NVARCHAR` — safe CSV landing)
5. Bulk inserts the CSV files
6. Cleans and type-casts data into clean staging tables
7. Builds the dimensional warehouse model

---

## Data Model

The dimensional model follows a star schema pattern:

- **Fact table:** listing performance metrics (price, occupancy, reviews, ratings)
- **Dimension tables:** host, property, location, date, weather

Open `model/CapeTownAirbnb_Model.drawio` at [draw.io](https://app.diagrams.net/) to view the full diagram.

---

## Design Decisions

**Why all staging columns are `NVARCHAR`**
Airbnb CSVs contain messy raw data — `"$1,200.00"` prices, `"NaN"` strings, empty fields in numeric columns. Loading everything as `NVARCHAR` prevents bulk insert failures. `TRY_CAST` is then used in the clean layer to safely convert types, returning `NULL` instead of throwing errors.

**Why Open-Meteo over OpenWeather**
OpenWeather's historical API (One Call 3.0) requires billing setup. Open-Meteo provides equivalent daily historical data, free and keyless, with structured JSON responses that integrate cleanly into the ETL pipeline.

**Bronze / Silver / Gold layering**

| Layer | Schema | Purpose |
|---|---|---|
| Bronze | `STG.stg_*_raw` | Raw CSV ingestion, all strings |
| Silver | `STG.stg_*_clean` | Typed, cleaned, validated |
| Gold | `DWH.*` | Dimensional model, analytics-ready |
